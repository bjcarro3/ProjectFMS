let screen = 0;
let bell;
let miss;
let win;

//Game1 vars
var score = 0;

let img2True = false;
let img3True = false;
let img4True = false;
let img5True = false;

var img2X = 60;
var img2Y = 210;
var img3X = 140;
var img3Y = 210;
var img4X = 60;
var img4Y = 290;
var img5X = 140;
var img5Y = 290;

var start2X = 0;
var start2Y = 0;
var start3X = 0;
var start3Y = 0;
var start4X = 0;
var start4Y = 0;
var start5X = 0;
var start5Y = 0;

let img2Correct = false;
let img3Correct = false;
let img4Correct = false;
let img5Correct = false;

let score2 = false;
let score3 = false;
let score4 = false;
let score5 = false;

var img2Count = 0;
var img3Count = 0;
var img4Count = 0;
var img5Count = 0;

//Game2 vars
let length1 = 100;
let length2 = 100;
let length3 = 100;
let length4 = 100;
let length5 = 100;
let rectx1 = 20;
let rectx2 = 20;
let rectx3 = 20;
let rectx4 = 20;
let rectx5 = 20;
let recty1 = 20;
let recty2 = 80;
let recty3 = 140;
let recty4 = 200;
let recty5 = 260;
let mx = 0;
let my = 0;
let selected = 0;
let ytarget = 375;
let xtarget1 = 250;
let xtarget2 = 450;
let locked1 = false;
let locked2 = true;
let locked3 = true;
let locked4 = true;
let locked5 = true;
let gameState = 0;

//Game3 vars
let currDot = 0;

//Game4 vars
let g4score=0;
let g4x = 0;
let g4y = 0;
let g4state = 0;
let timer = 0;

function setup() {
  //Load Sound Effects
  bell = loadSound('bell.mp3');
  miss = loadSound('incorrect.mp3');
  win = loadSound('win.mp3');
  //Load images
  img1 = loadImage("images/Main.png");
  img2 = loadImage("images/Part1.png");
  img3 = loadImage("images/Part2.png");
  img4 = loadImage("images/Part3.png");
  img5 = loadImage("images/Part4.png");
  //Create the canvas
  createCanvas(700, 500);
  background(245, 239, 230);
  //Set initial clicker position
  g4x=random(50, 650);
  g4y=random(50, 400);
}

function draw() {
  //Depending on the screen, draw that screen
  if(screen == 0){
    homeScreen();
  }
  else if(screen == 1){
    game1();
  }
  else if(screen == 2){
    game2();
  }
  else if(screen == 3){
    game3();
  }
  else if(screen ==4){
    game4();
  }
}
//Home Screen Draw function
function homeScreen(){
  strokeWeight(0.8);
  stroke("black");
  textAlign(CENTER, CENTER);
  background(245, 103, 120);
  fill(242, 92, 84);
  circle(130,220,600);
  fill(242, 112, 89);
  circle(130,180,500);
  fill(247, 157, 101);
  circle(130,150,400);
  
  fill(250,250,250);
  textSize(50);
  fill(0,0,0);
  textFont("Dancing Script");
  text("Welcome to", 150,55);
  textSize(90);
  textFont("Black and White Picture");
  text("PROJECT", 160,120);
  text("FMS", 150,190);
  textSize(20);
  textFont("Noto Serif");
  text("Select an option to launch a", 150, 240);
  text("game and improve",150,265);
  textFont("Merriweather");
  text(" fine-motor skills",150,293);
  
  //color of button background
  fill(255, 205, 178);
  rect(450,30,220,100);
  rect(450,150,220,100);
  rect(450,270,220,100);
  rect(450,390,220,100);
  
  fill (0,0,20);
  textSize(26);
  textFont("Roboto Condensed");
  text("Clicker", 560, 440);
  text("Stacker", 560, 200);
  text("Drag and Drop", 560, 80);
  text("Connect the Dots",560,320);
}
//Drag and Drop Draw Function
function game1(){
  background(255, 205, 178);
  rect(50, 200, 150, 150);
  textSize(25);
  textFont("Roboto Condensed");
  text("Drag the circles onto the holes to", 180, 30);
  text("complete the image.", 180, 55);
  
  text("Correct: " + score + " / 4", 75, 100);
  
  circle(464, 90, 50);
  circle(563, 80, 50);
  circle(491, 213, 50);
  circle(452, 339, 50);
  
  image(img1, 400, 10);
  image(img2, img2X, img2Y);
  image(img3, img3X, img3Y);
  image(img4, img4X, img4Y);
  image(img5, img5X, img5Y);
  fill(245, 103, 120);
  rect(0, 400, 200, 100);
  fill("black");
  textSize(25);
  text("Back to Menu", 100, 450);
  
  if(score == 4){
    textAlign(CENTER, CENTER);
    background(255,205,178);
    textSize(70);
    text("You win!", 350, 250);
    fill(245, 103, 120);
    rect(0, 400, 200, 100);
    textSize(25);
    fill("black");
    text("Back to Menu", 100, 450);
  }
}
//Stacker Draw Function
function game2(){
  if(gameState == 0){ //Default state
    background(255,205,178);
    textAlign(CENTER, CENTER);
    fill(242, 112, 89);
    //Platform
    rect(250, 400, 200, 20);
    //Draw each rectangle based on the variable position and length, if statements make the current moveable rectangle a different color stroke
    //Rect1
    if(locked1){
      fill(242, 112, 89);
    }
    else {
      fill("yellow");
    }
    rect(rectx1, recty1, length1, 20);
    
    //Rect2
    if(locked2){
      fill(242, 112, 89);
    }
    else {
      fill("yellow");
    }
    rect(rectx2, recty2, length2, 20);
    
    //Rect3
    if(locked3){
      fill(242, 112, 89);
    }
    else {
      fill("yellow");
    }
    rect(rectx3, recty3, length3, 20);
    
    //Rect4
    if(locked4){
      fill(242, 112, 89);
    }
    else {
      fill("yellow");
    }
    rect(rectx4, recty4, length4, 20);
    
    //Rect5
    if(locked5){
      fill(242, 112, 89);
    }
    else {
      fill("yellow");
    }
    rect(rectx5, recty5, length5, 20);
    fill(245, 103, 120);
    rect(0, 400, 200, 100);
    fill("black");
    strokeWeight(1);
    textSize(22);
    text("Back to Menu", 100, 450);
    textFont("Roboto Condensed");
    text("Drag the rectangles from top to bottom above the platform", 410, 20);
    text("to create a tower. Only the parts that line up will stay.", 410, 45);
  }
  else if(gameState == 1){ //When user wins
    background(255,205,178);
    textSize(70);
    text("You win!", 350, 250);
    fill(245, 103, 120);
    rect(0, 400, 200, 100);
    textSize(25);
    fill("black");
    text("Back to Menu", 100, 450);
  }
}
//Connect the Dots draw function
function game3(){
  //Only do draw function once
  noLoop();
  background(255,205,178);
  textAlign(CENTER, CENTER);
  //Draw dots
  fill("black");
  circle(215, 70, 5);
  textSize(15);
  text("1, 11", 240, 80);
  circle(175, 125, 5);
  text("2", 185, 135);
  circle(115, 165, 5);
  text("3", 125, 175);
  circle(175, 205, 5);
  text("4", 185, 215);
  circle(255, 125, 5);
  text("10", 265, 135);
  circle(315, 165, 5);
  text("9", 325, 175);
  circle(255, 205, 5);
  text("8", 265, 215);
  circle(215, 235, 5);
  text("6", 225, 245);
  circle(150, 275, 5);
  text("5", 160, 285);
  circle(280, 275, 5);
  text("7", 290, 285);
  fill(245, 103, 120);
  rect(0, 400, 200, 100);
  fill("black");
  textSize(25);
  text("Back to Menu", 100, 450);
  textSize(22);
  text("Connect the Dots In Order", 360, 20);
  textSize(15);
  text("(Click and Drag)", 360, 45);
}
//Function that draws Connect the Dots lose screen
function g3Lose(){
  miss.play();
  currDot = 0;
  background(255,205,178);
  textSize(40);
  fill("red");
  text("You connected the wrong dot", 350, 250);
  fill(245, 103, 120);
  rect(0, 400, 200, 100);
  textSize(25);
  fill("black");
  text("Reset", 100, 450);
  screen = 6; //Acts as a game state
}
//Clicker Draw Function
function game4(){
  strokeWeight(1);
  background(255,205,178);
  stroke("black");
  strokeWeight(1);
  text("<----Click the Circle as Many Times As You Can!",350,50);
  //If state 0, draw start button
  if(g4state == 0){
    fill(245, 103, 120);
    rect(250, 200, 200, 100);
    fill("black");
    text("Start!", 350, 250);
  }
  else { //If state isn't 0, draw the circle
    circle(g4x,g4y,50);
    text(30 - floor((millis() - timer) / 1000), 630, 50);
  }
  //If mouse is in the circle, make score green
  if(sqrt((mouseX-g4x)*(mouseX-g4x)+(mouseY-g4y)*(mouseY-g4y))<=25){
    stroke("green");
    strokeWeight(2);
    text(g4score,50,50);
  }
  //If mouse is outside circle, make score red
  else{
    stroke("red");
    strokeWeight(2);
    text(g4score,50,50);
  }
  strokeWeight(1);
  stroke("black");
  fill(245, 103, 120);
  rect(0, 400, 200, 100);
  fill("black");
  text("Back to Menu", 100, 450);
  //Once 30 seconds have passed, set the game state to 2
  if(g4state == 1 && millis() >= timer + 30000){
    g4state = 2;
  }
  //End state, draws blank screen with congratulations and score
  if(g4state == 2){
    background(255,205,178);
    textSize(70);
    text("You got " + g4score + " points!", 350, 250);
    fill(245, 103, 120);
    rect(0, 400, 200, 100);
    textSize(25);
    fill("black");
    text("Back to Menu", 100, 450);
  }
}

function mousePressed(){
  //Home Screen, sets default values on entry to new screen
  if(screen == 0){
    if(mouseX >= 450 && mouseX <= 670 && mouseY >= 30 && mouseY <= 130){
      screen = 1;
      score = 0;
      img2True = false;
      img3True = false;
      img4True = false;
      img5True = false;
      img2X = 60;
      img2Y = 210;
      img3X = 140;
      img3Y = 210;
      img4X = 60;
      img4Y = 290;
      img5X = 140;
      img5Y = 290;
      start2X = 0;
      start2Y = 0;
      start3X = 0;
      start3Y = 0;
      start4X = 0;
      start4Y = 0;
      start5X = 0;
      start5Y = 0;
      img2Correct = false;
      img3Correct = false;
      img4Correct = false;
      img5Correct = false;
      score2 = false;
      score3 = false;
      score4 = false;
      score5 = false;
      img2Count = 0;
      img3Count = 0;
      img4Count = 0;
      img5Count = 0;
    }
    else if(mouseX >= 450 && mouseX <= 670 && mouseY >= 150 && mouseY <=250){
      screen = 2;
      length1 = 100;
      length2 = 100;
      length3 = 100;
      length4 = 100;
      length5 = 100;
      rectx1 = 20;
      rectx2 = 20;
      rectx3 = 20;
      rectx4 = 20;
      rectx5 = 20;
      recty1 = 20;
      recty2 = 80;
      recty3 = 140;
      recty4 = 200;
      recty5 = 260;
      mx = 0;
      my = 0;
      ytarget = 375;
      xtarget1 = 250;
      xtarget2 = 450;
      locked1 = false;
      locked2 = true;
      locked3 = true;
      locked4 = true;
      locked5 = true;
      gameState = 0;
    }
    else if(mouseX >= 450 && mouseX <= 670 && mouseY >= 270 && mouseY <= 370){
      screen = 3;
      currDot = 0;
    }
    else if(mouseX >= 450 && mouseX <= 670 && mouseY >= 390 && mouseY <= 490){
      g4score = 0;
      screen = 4;
      g4state = 0;
      timer = 0;
    }
  }
  
  //Game 1
  else if(screen == 1){
    //Home Button
    if(mouseX >= 0 && mouseX <= 200 && mouseY >= 400 && mouseY <=500){
      screen = 0;
    }
    //For each circle, if it isn't in place, set it as selected and store mouse position when grabbing
    if (mouseX > img2X && mouseX < img2X + 50 && mouseY > img2Y && mouseY < img2Y + 50) {
      if (!img2Correct) {
        img2True = true;
        start2X = mouseX;
        start2Y = mouseY;
      }
    }
    if (mouseX > img3X && mouseX < img3X + 50 && mouseY > img3Y && mouseY < img3Y + 50) {
       img3True = true;
       start3X = mouseX;
       start3Y = mouseY;
    }
    if (mouseX > img4X && mouseX < img4X + 50 && mouseY > img4Y && mouseY < img4Y + 50) {
      img4True = true;
      start4X = mouseX;
      start4Y = mouseY;
    }
    if (mouseX > img5X && mouseX < img5X + 50 && mouseY > img5Y && mouseY < img5Y + 50) {
      img5True = true;
      start5X = mouseX;
      start5Y = mouseY;
    }    
  }
  
  //Game 2
  else if(screen == 2){
    //Home Button
    if(mouseX >= 0 && mouseX <= 200 && mouseY >= 400 && mouseY <=500){
      screen = 0;
    }
    //Updates which rectangle is selected, then stores distance mouse is from the starting corner
    //Rect1
    if(mouseX >= rectx1 && mouseX <= rectx1 + length1 && mouseY >= recty1 && mouseY <= recty1+20 && !locked1){
      mx = mouseX - rectx1;
      my = mouseY - recty1;
      selected = 1;
    }

    //Rect2
    else if(mouseX >= rectx2 && mouseX <= rectx2 + length2 && mouseY >= recty2 && mouseY <= recty2+20 && !locked2){
      mx = mouseX - rectx2;
      my = mouseY - recty2;
      selected = 2;
    }

    //Rect3
    else if(mouseX >= rectx3 && mouseX <= rectx3 + length3 && mouseY >= recty3 && mouseY <= recty3+20 && !locked3){
      mx = mouseX - rectx3;
      my = mouseY - recty3;
      selected = 3;
    }

    //Rect4
    else if(mouseX >= rectx4 && mouseX <= rectx4 + length4 && mouseY >= recty4 && mouseY <= recty4+20 && !locked4){
      mx = mouseX - rectx4;
      my = mouseY - recty4;
      selected = 4;
    }

    //Rect5
    else if(mouseX >= rectx5 && mouseX <= rectx5 + length5 && mouseY >= recty5 && mouseY <= recty5+20 && !locked5){
      mx = mouseX - rectx5;
      my = mouseY - recty5;
      selected = 5;
    }
  }
  
  //Game 3
  else if(screen == 3){
    //Home Button, restarts draw loop
    if(mouseX >= 0 && mouseX <= 200 && mouseY >= 400 && mouseY <=500){
      screen = 0;
      loop();
    }
  }
  //Game 3 Lose Screen and reset button
  else if(screen == 6){
    if(mouseX >= 0 && mouseX <= 200 && mouseY >= 400 && mouseY <=500){
      game3();
      screen = 3;
    }
  }
  //Game 4
  else if (screen == 4){
    //Home Button
    if(mouseX >= 0 && mouseX <= 200 && mouseY >= 400 && mouseY <=500){
      screen = 0;
    }
    //If circle is clicked, state 1 only
    else if(g4state == 1 && sqrt((mouseX-g4x)*(mouseX-g4x)+(mouseY-g4y)*(mouseY-g4y))<=25){
      g4score=g4score+1;
      bell.play();
    }
    //If circle is missed, state 1 only
    else if(g4state == 1) {
      miss.play();
      g4score=g4score-1;
    }
    //When start is clicked, change state and store start time
    if(g4state == 0 && mouseX >= 250 && mouseX <= 450 && mouseY >= 200 && mouseY <= 300){
      g4state = 1;
      timer = millis();
    }
    //Every click, reset circle position
    g4x = random(50, 650);
    g4y = random(50, 400);
  }
  
}

function mouseDragged(){
  //Game1
  if(screen == 1){
    //Change position of selected segment based on mouse position, then sets the segment as correct or not if the mouse is in the correct position
    if (img2True && img2Count == 0) {
      var change2X = start2X - mouseX;
      img2X -= change2X;
      start2X = mouseX;

      var change2Y = start2Y - mouseY;
      img2Y -= change2Y;
      start2Y = mouseY;
    }
    if (img3True && img3Count == 0) {
      var change3X = start3X - mouseX;
      img3X -= change3X;
      start3X = mouseX;

      var change3Y = start3Y - mouseY;
      img3Y -= change3Y;
      start3Y = mouseY;
    }
    if (img4True && img4Count == 0) {
      var change4X = start4X - mouseX;
      img4X -= change4X;
      start4X = mouseX;

      var change4Y = start4Y - mouseY;
      img4Y -= change4Y;
      start4Y = mouseY;
    }
    if (img5True && img5Count == 0) {
      var change5X = start5X - mouseX;
      img5X -= change5X;
      start5X = mouseX;

      var change5Y = start5Y - mouseY;
      img5Y -= change5Y;
      start5Y = mouseY;
    }
    if (img2True && mouseX > 430 && mouseX < 500 && mouseY > 50 && mouseY < 120) {
      img2Correct = true;
    }
    else {
      img2Correct = false;
    }
      if (img3True && mouseX > 460 && mouseX < 520 && mouseY > 180 && mouseY < 245) {
      img3Correct = true;
    }
    else {
      img3Correct = false;
    }
      if (img4True && mouseX > 420 && mouseX < 480 && mouseY > 310 && mouseY < 370) {
      img4Correct = true;
    }
    else {
      img4Correct = false;
    }
      if (img5True && mouseX > 530 && mouseX < 590 && mouseY > 45 && mouseY < 110) {
      img5Correct = true;
    }
    else {
      img5Correct = false;
    }
  }
  
  
  //Game2
  if(screen == 2){
    //Update Rectangle position based on mouse position
    //Rect1
    if(!locked1 && selected == 1){
      rectx1 = mouseX - mx;
      recty1 = mouseY - my;
    }

    //Rect2
    else if(!locked2 && selected == 2){
      rectx2 = mouseX - mx;
      recty2 = mouseY - my;
    }

    //Rect3
    else if(!locked3 && selected == 3){
      rectx3 = mouseX - mx;
      recty3 = mouseY - my;
    }

    //Rect4
    else if(!locked4 && selected == 4){
      rectx4 = mouseX - mx;
      recty4 = mouseY - my;
    }

    //Rect5
    else if(!locked5 && selected == 5){
      rectx5 = mouseX - mx;
      recty5 = mouseY - my;
    }
  }
  
  //Game3
  if(screen == 3){
    //Each dot, if in order, update the current dot reached and change number text to green, if out of order, draw lose screen
    if(dist(mouseX, mouseY, 215, 70) <= 5){
      if(currDot == 0){
        bell.play();
        currDot++;
        fill("green");
        text("1", 229, 80);
      }
      else if(currDot != 1 && currDot != 10 && currDot != 11){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 175, 125) <= 5){
      if(currDot == 1){
        bell.play();
        text("2", 185, 135);
        currDot++;
      }
      else if(currDot != 2){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 115, 165) <= 5){
      if(currDot == 2){
        bell.play();
        text("3", 125, 175);
        currDot++;
      }
      else if(currDot != 3){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 175, 205) <= 5){
      if(currDot == 3){
        bell.play();
        text("4", 185, 215);
        currDot++;
      }
      else if(currDot != 4){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 150, 275) <= 5){
      if(currDot == 4){
        bell.play();
        text("5", 160, 285);
        currDot++;
      }
      else if(currDot != 5){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 215, 235) <= 5){
      if(currDot == 5){
        bell.play();
        text("6", 225, 245);
        currDot++;
      }
      else if(currDot != 6){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 280, 275) <= 5){
      if(currDot == 6){
        bell.play();
        text("7", 290, 285);
        currDot++;
      }
      else if(currDot != 7){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 255, 205) <= 5){
      if(currDot == 7){
        bell.play();
        text("8", 265, 215);
        currDot++;
      }
      else if(currDot != 8){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 315, 165) <= 5){
      if(currDot == 8){
        bell.play();
        text("9", 325, 175);
        currDot++;
      }
      else if(currDot != 9){
        g3Lose();
      }
    }
    else if(dist(mouseX, mouseY, 255, 125) <= 5){
      if(currDot == 9){
        bell.play();
        text("10", 265, 135);
        currDot++;
      }
      else if(currDot != 10){
        g3Lose();
      }
    }
    //Win condition, draws star and congratulations text
    if(dist(mouseX, mouseY, 215, 70) <= 5){
      if(currDot == 10){
        bell.play();
        text("1, 11", 240, 80);
        currDot++;
        line(515, 70, 475, 125);
        line(475, 125, 415, 165);
        line(415, 165, 475, 205);
        line(475, 205, 450, 275);
        line(450, 275, 515, 235);
        line(515, 235, 580, 275);
        line(580, 275, 555, 205);
        line(555, 205, 615, 165);
        line(615, 165, 555, 125);
        line(555, 125, 515, 70);
        textSize(25);
        text("Congratulations, you drew a star!", 450, 435);
        text("How close was your drawing to the picture?", 450, 465);
      }
    }
    //Draw small circles as mouse is moved
    circle(mouseX, mouseY, 3);
  }
}

function mouseReleased(){
  //Game1
  if(screen == 1){
    //When segment placed in correct spot, lock it in place and update score
    if (img2Correct) {
      bell.play();
      img2X = 440;
      img2Y = 66;
      if (!score2) {
        score ++;
        img2Count ++;
        score2 = true;
        img2True = false;
      }
    }
    if (img3Correct) {
      bell.play();
      img3X = 468;
      img3Y = 189;
      if (!score3) {
        score ++;
        img3Count++;
        score3 = true;
        img3True = false;
      }
    }
    if (img4Correct) {
      bell.play();
      img4X = 428;
      img4Y = 314;
      if (!score4) {
        score ++;
        img4Count++;
        score4 = true;
        img4True = false;
      }
    }
    if (img5Correct) {
      bell.play();
      img5X = 539;
      img5Y = 55;
      if (!score5) {
        score ++;
        img5Count++;
        score5 = true;
        img5True = false;
      }
    }
    if(score == 4){
      win.play();
    }
    //Miss
    if(img2True || img3True || img4True || img5True){
      miss.play();
    }
    //Deselect all
    img2True = false;
    img3True = false;
    img4True = false;
    img5True = false;
  }
  
  //Game2
  if(screen == 2){
    //For each rectangle, if rectangle is being moved, and is within target cut off the rectangle and change next rectangles lengths. Locks the rectangle and unlocks the next one
    //rect1
    if(!locked1 && recty1 >= ytarget && recty1 <= ytarget + 15 && ((rectx1 >= xtarget1 && rectx1 <= xtarget2) || rectx1+length1 <= xtarget2 && rectx1+length1 >= xtarget1)){
      if(rectx1 < xtarget1){
        length1 = length1 - (xtarget1-rectx1);
        length2 = length1;
        length3 = length1;
        length4 = length1;
        length5 = length1;
        rectx1 = xtarget1;
      }
      else if(rectx1+length1 > xtarget2){
        length1 = length1 - (rectx1+length1 - xtarget2);
        length2 = length1;
        length3 = length1;
        length4 = length1;
        length5 = length1;
      }
      ytarget = recty1 - 25;
      xtarget1 = rectx1;
      xtarget2 = rectx1 + length1;
      locked1 = true;
      locked2 = false;
      bell.play();
    }

    //rect2
    else if(!locked2 && recty2 >= ytarget && recty2 <= ytarget + 15 && ((rectx2 >= xtarget1 && rectx2 <= xtarget2) || rectx2+length2 <= xtarget2 && rectx2+length2 >= xtarget1)){
      if(rectx2 < xtarget1){
        length2 = length2 - (xtarget1-rectx2);
        length3 = length2;
        length4 = length2;
        length5 = length2;
        rectx2 = xtarget1;
      }
      else if(rectx2+length2 > xtarget2){
        length2 = length2 - (rectx2+length2 - xtarget2);
        length3 = length2;
        length4 = length2;
        length5 = length2;
      }
      ytarget = recty2 - 25;
      xtarget1 = rectx2;
      xtarget2 = rectx2 + length2;
      locked2 = true;
      locked3 = false;
      bell.play();
    }

    //Rect 3
    else if(!locked3 && recty3 >= ytarget && recty3 <= ytarget + 15 && ((rectx3 >= xtarget1 && rectx3 <= xtarget2) || rectx3+length3 <= xtarget2 && rectx3+length3 >= xtarget1)){
      if(rectx3 < xtarget1){
        length3 = length3 - (xtarget1-rectx3);
        length4 = length3;
        length5 = length3;
        rectx3 = xtarget1;
      }
      else if(rectx3+length3 > xtarget2){
        length3 = length3 - (rectx3+length3 - xtarget2);
        length4 = length3;
        length5 = length3;
      }
      ytarget = recty3 - 25;
      xtarget1 = rectx3;
      xtarget2 = rectx3 + length3;
      locked3 = true;
      locked4 = false;
      bell.play();
    }

      //Rect 4
    else if(!locked4 && recty4 >= ytarget && recty4 <= ytarget + 15 && ((rectx4 >= xtarget1 && rectx4 <= xtarget2) || rectx4+length4 <= xtarget2 && rectx4+length4 >= xtarget1)){
      if(rectx4 < xtarget1){
        length4 = length4 - (xtarget1-rectx4);
        length5 = length4;
        rectx4 = xtarget1;
      }
      else if(rectx4+length4 > xtarget2){
        length4 = length4 - (rectx4+length4 - xtarget2);
        length5 = length4;
      }
      ytarget = recty4 - 25;
      xtarget1 = rectx4;
      xtarget2 = rectx4 + length4;
      locked4 = true;
      locked5 = false;
      bell.play();
    }

    //Rect5
    else if(!locked5 && recty5 >= ytarget && recty5 <= ytarget + 15 && ((rectx5 >= xtarget1 && rectx5 <= xtarget2) || rectx5+length5 <= xtarget2 && rectx5+length5 >= xtarget1)){
      if(rectx5 < xtarget1){
        length5 = length5 - (xtarget1-rectx5);
        rectx5 = xtarget1;
      }
      else if(rectx5+length5 > xtarget2){
        length5 = length5 - (rectx5+length5 - xtarget2);
      }
      //Change game state to win to draw win
      locked5 = true;
      gameState = 1;
      win.play();
    }
    //If rectangle released not in target, play miss sound
    else if (selected != 0) {
      miss.play();
    }
    //Deselect when released
    selected = 0;
  }
}